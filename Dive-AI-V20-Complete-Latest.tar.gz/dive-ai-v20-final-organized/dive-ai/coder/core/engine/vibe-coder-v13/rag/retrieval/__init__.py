"RAG retrieval utilities (fusion, dense index)."
