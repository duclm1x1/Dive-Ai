# Merge Report — Dive AI v20 Final Organized (Patch)

This patch helps you reorganize an extracted v20 package into the final layout:
- `v20/` mainline with `coder`, `orchestrator`, `skills`, `runtime`, `docs`
- dist-only UI cleanup (remove `node_modules/`, UI sources)
- cache cleanup (`__pycache__`, `*.pyc`)
