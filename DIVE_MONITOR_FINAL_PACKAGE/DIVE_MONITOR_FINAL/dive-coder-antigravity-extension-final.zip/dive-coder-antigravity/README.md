# Dive Coder V15.3 - Antigravity Extension

**One command. Everything included. Real-time monitoring.**

```bash
npx dive-coder
```

This command installs Dive Coder V15.3 + Dive Monitor UI directly into Antigravity as an extension tab, with integrated CLI interface and real-time metrics dashboard.

## 🎯 What is This?

Dive Coder V15.3 is an AI-powered code analysis platform. This extension brings it directly into Antigravity with:

- **CLI Tab** - Execute Dive Coder commands directly from Antigravity
- **Metrics Dashboard** - Real-time performance monitoring
- **Event History** - Browse execution history
- **One-Command Setup** - `npx dive-coder` handles everything

## 🚀 Quick Start

### Prerequisites

- **Antigravity** - Install from [antigravity.dev](https://antigravity.dev)
- **Node.js 18+** - For NPX
- **Python 3.8+** - For Dive Coder

### Installation

```bash
# Single command - that's it!
npx dive-coder
```

This will:
1. Detect your OS and Antigravity installation
2. Install Python dependencies
3. Start the Sync Bridge server
4. Launch Antigravity with Dive Coder extension
5. Open the CLI tab ready to use

### First Command

```bash
# In the CLI tab, type:
> status

# Or analyze code:
> process --input "Review this function"
```

## 📋 Available Commands

### Status & Info

```bash
# Check system status
> status

# Get component info
> component --name dive_engine
> component --name monitoring
> component --name rag

# Get help
> help
```

### Code Analysis

```bash
# Analyze code
> process --input "Review this code"

# Explain code
> process --input "Explain how this works" --mode explain

# Fix issues
> process --input "Fix the bug" --mode fix
```

### Monitoring

```bash
# Check sync status
> sync-status

# Get events
> sync-pull --type events --limit 100

# Check bridge health
> sync-health
```

## 🎮 Tab Interface

### CLI Tab

Execute commands directly in Antigravity:

```
┌─────────────────────────────────────────┐
│  Dive Coder CLI                         │
├─────────────────────────────────────────┤
│ $ status                                │
│ {                                       │
│   "success": true,                      │
│   "version": "15.3",                    │
│   "components": {...}                   │
│ }                                       │
├─────────────────────────────────────────┤
│ $ [process --input "..."]               │
│ [Clear] [Copy] [Export]                 │
└─────────────────────────────────────────┘
```

**Features:**
- Autocomplete (Tab key)
- Command history (↑↓ keys)
- Copy output (Ctrl+C)
- Export to file
- Real-time results

### Metrics Tab

Real-time performance monitoring:

```
Connection Status: ✓ Connected
Session ID: abc123def456
Uptime: 2h 15m

Performance Metrics:
  Total Duration: 1.23s
  LLM Time: 0.89s
  Tool Time: 0.34s
  Latency (p50): 45ms
  Latency (p95): 120ms

Token Usage:
  Input: 2,450
  Output: 1,200
  Total: 3,650

Recent Commands:
  1. process --input "Review code"
  2. status
  3. component --name dive_engine
```

### History Tab

Browse execution history with filtering and export.

## 🔧 Configuration

### Environment Variables

```bash
# Sync Bridge port (default: 8787)
DIVE_CODER_PORT=8787

# Python executable path
PYTHON_PATH=/usr/bin/python3

# Antigravity installation path
ANTIGRAVITY_PATH=/Applications/Antigravity.app

# Debug mode
DEBUG=true
```

### Config File

Create `~/.dive-coder/config.json`:

```json
{
  "version": "15.3",
  "antigravity_path": "/Applications/Antigravity.app",
  "python_path": "/usr/bin/python3",
  "sync_bridge_port": 8787,
  "auto_start": true,
  "theme": "dark",
  "refresh_interval": 1000
}
```

## 📊 Architecture

```
┌──────────────────────────┐
│   Antigravity Extension  │
│  ┌────────────────────┐  │
│  │ CLI Tab            │  │
│  │ Metrics Tab        │  │
│  │ History Tab        │  │
│  └────────────────────┘  │
└────────────┬─────────────┘
             │ WebSocket
             ▼
┌──────────────────────────┐
│  Sync Bridge Server      │
│  (Node.js/Express)       │
│  Port: 8787              │
└────────────┬─────────────┘
             │ HTTP/REST
             ▼
┌──────────────────────────┐
│  Dive Coder V15.3        │
│  (Python CLI)            │
│  - Dive Engine           │
│  - RAG System            │
│  - Governance            │
│  - 61 Skills             │
└──────────────────────────┘
```

## 🧪 Testing

### Verify Installation

```bash
# Check Sync Bridge is running
curl http://localhost:8787/health

# Check Dive Coder is connected
npx dive-coder status

# Run test command
npx dive-coder process --input "Test"
```

### Run Tests

```bash
# Unit tests
npm test

# Integration tests
npm run test:integration

# E2E tests
npm run test:e2e
```

## 🐛 Troubleshooting

### Connection Issues

**Problem:** "Cannot connect to Antigravity"

**Solution:**
```bash
# Verify Antigravity is running
ps aux | grep antigravity

# Check if port 8787 is available
lsof -i :8787

# Restart Sync Bridge
npx dive-coder --restart
```

### Python Not Found

**Problem:** "Python 3.8+ not found"

**Solution:**
```bash
# Specify Python path
npx dive-coder --python-path /usr/bin/python3

# Or set environment variable
export PYTHON_PATH=/usr/bin/python3
npx dive-coder
```

### Commands Not Working

**Problem:** "Command execution failed"

**Solution:**
```bash
# Enable debug mode
DEBUG=true npx dive-coder

# Check Sync Bridge logs
cat ~/.dive-coder/sync-bridge/logs/sync-bridge.log

# Verify connection
> sync-status
```

## 📈 Performance

Expected performance metrics:

| Metric | Target | Typical |
|--------|--------|---------|
| Installation | < 2 min | 1.5 min |
| Startup | < 5 sec | 3 sec |
| CLI Response | < 1 sec | 0.5 sec |
| Metrics Update | < 100ms | 50ms |
| Memory Usage | < 200MB | 150MB |

## 🔐 Security

- All commands are validated before execution
- Python execution is sandboxed
- WebSocket uses secure protocols (WSS in production)
- No sensitive data in logs
- Rate limiting on API calls

## 🎯 Use Cases

### Code Review

```bash
> process --input "Review this function for bugs"
```

### Documentation

```bash
> process --input "Generate documentation for this module"
```

### Testing

```bash
> process --input "Generate unit tests for this code"
```

### Refactoring

```bash
> process --input "Refactor this code for performance"
```

### Learning

```bash
> process --input "Explain how this algorithm works"
```

## 📚 Documentation

- **[INSTALLATION.md](./INSTALLATION.md)** - Detailed setup guide
- **[USAGE.md](./USAGE.md)** - Command reference
- **[API.md](./API.md)** - REST API documentation
- **[ARCHITECTURE.md](./ARCHITECTURE.md)** - System design
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** - Common issues

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

MIT License - See [LICENSE](./LICENSE) file

## 🆘 Support

### Getting Help

1. Check [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)
2. Review logs: `cat ~/.dive-coder/sync-bridge/logs/sync-bridge.log`
3. Enable debug: `DEBUG=true npx dive-coder`
4. Open an issue on GitHub

### Reporting Bugs

Please include:
- OS and version
- Node.js version
- Python version
- Error message
- Steps to reproduce
- Debug logs

## 🎉 What's Included

### Dive Coder V15.3 Components

- **Dive Engine** - Core orchestration
- **Antigravity Plugin** - Antigravity integration
- **MCP Support** - Model Context Protocol
- **Monitoring System** - Real-time event tracking
- **RAG System** - Retrieval-Augmented Generation
- **Governance** - Quality gates and validation
- **Graph Analysis** - Import and impact analysis
- **Builder** - Project scaffolding
- **61 Skills** - Pre-built capabilities
- **Dive Context** - Documentation server

### Extension Features

- **CLI Interface** - Command execution
- **Metrics Dashboard** - Real-time monitoring
- **Event History** - Execution tracking
- **Sync Bridge** - Real-time communication
- **WebSocket Support** - Live updates
- **REST API** - HTTP endpoints
- **Auto-reconnect** - Fault tolerance
- **Dark/Light Themes** - UI customization

## 🚀 Next Steps

1. **Install:** `npx dive-coder`
2. **Explore:** Try `> status` command
3. **Analyze:** Use `> process --input "..."`
4. **Monitor:** Check Metrics tab
5. **Learn:** Read [USAGE.md](./USAGE.md)

---

**Happy coding with Dive Coder! 🤿**

For more information, visit [dive-coder.dev](https://dive-coder.dev)
