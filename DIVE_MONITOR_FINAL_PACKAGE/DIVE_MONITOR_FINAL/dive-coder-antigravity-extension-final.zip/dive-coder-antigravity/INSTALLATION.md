# Installation Guide - Dive Coder Antigravity Extension

## Prerequisites

Before installing, ensure you have:

### Required

- **Antigravity** - Latest version
  - [Download](https://antigravity.dev/download)
  - [Installation Guide](https://antigravity.dev/install)

- **Node.js 18+**
  - [Download](https://nodejs.org)
  - Verify: `node --version`

- **Python 3.8+**
  - [Download](https://python.org)
  - Verify: `python3 --version`

### Optional

- **Git** - For cloning repository
- **npm** - Usually comes with Node.js
- **pip** - Usually comes with Python

## Installation Methods

### Method 1: NPX (Recommended)

The easiest way - one command:

```bash
npx dive-coder
```

This automatically:
1. Detects your OS
2. Finds Antigravity installation
3. Installs Python dependencies
4. Starts Sync Bridge
5. Launches Antigravity with extension
6. Opens CLI tab

### Method 2: Global Installation

Install globally for repeated use:

```bash
npm install -g dive-coder
dive-coder
```

### Method 3: Local Installation

Clone and install locally:

```bash
git clone https://github.com/dive-team/dive-coder-antigravity.git
cd dive-coder-antigravity
npm install
npm start
```

## Step-by-Step Installation

### Step 1: Verify Prerequisites

```bash
# Check Node.js
node --version
# Should output: v18.0.0 or higher

# Check npm
npm --version
# Should output: 9.0.0 or higher

# Check Python
python3 --version
# Should output: Python 3.8.0 or higher
```

### Step 2: Install Antigravity (if not already installed)

```bash
# macOS
brew install antigravity

# Linux
sudo apt-get install antigravity

# Windows
choco install antigravity

# Or download from https://antigravity.dev/download
```

### Step 3: Run Installation

```bash
npx dive-coder
```

You should see:

```
╔════════════════════════════════════════════════════════╗
║   Dive Coder V15.3 - Antigravity Extension             ║
║   "Best of All" Edition                                ║
║   One Command. Everything Included.                    ║
╚════════════════════════════════════════════════════════╝

Version: 1.0.0

✓ OS detected: macOS (arm64)
✓ Environment validated ✓
✓ Antigravity found: /Applications/Antigravity.app
✓ Python dependencies installed ✓
✓ Sync Bridge ready: http://localhost:8787
✓ Extension registered ✓

✓ Installation complete!

Starting Antigravity with Dive Coder extension...
```

### Step 4: Verify Installation

Antigravity should open with a new "Dive Coder" tab. Try:

```bash
> status
```

You should see the system status output.

## Advanced Installation

### Custom Python Path

```bash
npx dive-coder --python-path /usr/bin/python3.11
```

### Custom Antigravity Path

```bash
npx dive-coder --antigravity-path /Applications/Antigravity.app
```

### Custom Sync Bridge Port

```bash
npx dive-coder --port 9000
```

### Development Mode

```bash
npx dive-coder --dev
```

### Debug Mode

```bash
DEBUG=true npx dive-coder
```

## Troubleshooting Installation

### Issue: "Antigravity not found"

**Solution:**
```bash
# Verify Antigravity is installed
which antigravity

# Or specify path
npx dive-coder --antigravity-path /path/to/antigravity
```

### Issue: "Python 3.8+ not found"

**Solution:**
```bash
# Install Python
# macOS
brew install python@3.11

# Linux
sudo apt-get install python3.11

# Windows
# Download from https://python.org

# Specify path
npx dive-coder --python-path /usr/bin/python3.11
```

### Issue: "Port 8787 already in use"

**Solution:**
```bash
# Use different port
npx dive-coder --port 8788

# Or kill process using port 8787
lsof -i :8787
kill -9 <PID>
```

### Issue: "npm: command not found"

**Solution:**
```bash
# Install Node.js from https://nodejs.org
# Or use package manager

# macOS
brew install node

# Linux
sudo apt-get install nodejs npm

# Windows
choco install nodejs
```

### Issue: Installation hangs

**Solution:**
```bash
# Cancel with Ctrl+C
# Try again with debug mode
DEBUG=true npx dive-coder

# Check internet connection
ping google.com

# Try with specific Python path
npx dive-coder --python-path /usr/bin/python3
```

## Post-Installation

### First Run

1. Antigravity opens with Dive Coder tab
2. Try command: `> status`
3. Check Metrics tab for real-time data
4. Browse History tab for past events

### Configuration

Create `~/.dive-coder/config.json`:

```json
{
  "theme": "dark",
  "refresh_interval": 1000,
  "auto_start": true,
  "sync_bridge_port": 8787
}
```

### Environment Variables

```bash
# Add to ~/.bashrc or ~/.zshrc
export DIVE_CODER_PORT=8787
export PYTHON_PATH=/usr/bin/python3
export ANTIGRAVITY_PATH=/Applications/Antigravity.app
```

## Updating

### Update to Latest Version

```bash
npm install -g dive-coder@latest
```

### Check Current Version

```bash
npx dive-coder --version
```

## Uninstallation

### Remove Global Installation

```bash
npm uninstall -g dive-coder
```

### Remove Configuration

```bash
rm -rf ~/.dive-coder
```

### Remove Extension

```bash
rm -rf ~/.antigravity/extensions/dive-coder
```

## System Requirements

### Minimum

- **OS:** macOS 10.15+, Ubuntu 18.04+, Windows 10+
- **CPU:** 2 cores
- **RAM:** 2GB
- **Disk:** 500MB free space

### Recommended

- **OS:** Latest version
- **CPU:** 4+ cores
- **RAM:** 8GB+
- **Disk:** 1GB+ free space
- **Network:** Broadband internet (for LLM features)

## Platform-Specific Notes

### macOS

```bash
# If you get permission denied:
sudo chown -R $(whoami) /usr/local/lib/node_modules

# For M1/M2 Macs, ensure you have arm64 Python
python3 -c "import platform; print(platform.machine())"
# Should output: arm64
```

### Linux

```bash
# Install system dependencies
sudo apt-get install build-essential python3-dev

# For Fedora/RHEL
sudo yum install gcc python3-devel
```

### Windows

```bash
# Use PowerShell as Administrator
# Or use Windows Subsystem for Linux (WSL)

# For WSL
wsl --install
# Then follow Linux instructions
```

## Verification Checklist

- [ ] Node.js 18+ installed
- [ ] Python 3.8+ installed
- [ ] Antigravity installed
- [ ] `npx dive-coder` runs successfully
- [ ] Antigravity opens with Dive Coder tab
- [ ] `> status` command works
- [ ] Metrics tab shows data
- [ ] History tab shows events

## Next Steps

1. Read [README.md](./README.md) for overview
2. Check [USAGE.md](./USAGE.md) for commands
3. Try [EXAMPLES.md](./EXAMPLES.md) for use cases
4. Review [API.md](./API.md) for REST API

## Getting Help

- **Documentation:** See [README.md](./README.md)
- **Troubleshooting:** See [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)
- **Issues:** Report on [GitHub](https://github.com/dive-team/dive-coder-antigravity/issues)
- **Community:** Join [Discord](https://discord.gg/dive-coder)

---

**Installation complete! Happy diving! 🤿**
