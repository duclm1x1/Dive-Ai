/**
 * OS Detection Utility
 * Detect operating system and architecture
 */

const os = require('os');
const { execSync } = require('child_process');

/**
 * Detect OS information
 */
async function detectOS() {
  const platform = os.platform(); // 'darwin', 'linux', 'win32'
  const arch = os.arch(); // 'x64', 'arm64', etc.
  const release = os.release();
  const type = os.type(); // 'Darwin', 'Linux', 'Windows_NT'

  let osName = 'Unknown';
  let osVersion = release;

  switch (platform) {
    case 'darwin':
      osName = 'macOS';
      try {
        osVersion = execSync('sw_vers -productVersion', { encoding: 'utf8' }).trim();
      } catch (e) {
        // Fallback to release
      }
      break;
    case 'linux':
      osName = 'Linux';
      try {
        const lsb = execSync('lsb_release -ds', { encoding: 'utf8' }).trim();
        osVersion = lsb.replace(/"/g, '');
      } catch (e) {
        // Fallback
      }
      break;
    case 'win32':
      osName = 'Windows';
      osVersion = type;
      break;
  }

  return {
    platform: osName,
    platformCode: platform,
    arch,
    release: osVersion,
    nodeVersion: process.version,
    npmVersion: getNpmVersion()
  };
}

/**
 * Get NPM version
 */
function getNpmVersion() {
  try {
    return execSync('npm --version', { encoding: 'utf8' }).trim();
  } catch (e) {
    return 'unknown';
  }
}

/**
 * Check if running on specific OS
 */
function isOS(osName) {
  const platform = os.platform();
  switch (osName.toLowerCase()) {
    case 'macos':
    case 'darwin':
      return platform === 'darwin';
    case 'linux':
      return platform === 'linux';
    case 'windows':
    case 'win32':
      return platform === 'win32';
    default:
      return false;
  }
}

/**
 * Check if running on ARM architecture
 */
function isARM() {
  const arch = os.arch();
  return arch === 'arm64' || arch === 'arm';
}

/**
 * Check if running on x64 architecture
 */
function isX64() {
  const arch = os.arch();
  return arch === 'x64' || arch === 'x86_64';
}

module.exports = {
  detectOS,
  getNpmVersion,
  isOS,
  isARM,
  isX64
};
