/**
 * Find Antigravity Installation
 * Locate Antigravity on the system
 */

const path = require('path');
const fs = require('fs-extra');
const os = require('os');
const { execSync } = require('child_process');
const which = require('which');

/**
 * Find Antigravity installation path
 */
async function findAntigravity(osInfo) {
  const platform = osInfo.platformCode;

  // Try different search strategies
  let antigravityPath = null;

  // Strategy 1: Check common installation paths
  antigravityPath = checkCommonPaths(platform);
  if (antigravityPath) return antigravityPath;

  // Strategy 2: Check PATH environment variable
  antigravityPath = checkPATH();
  if (antigravityPath) return antigravityPath;

  // Strategy 3: Check home directory
  antigravityPath = checkHomeDirectory(platform);
  if (antigravityPath) return antigravityPath;

  // Strategy 4: Try to find via system commands
  antigravityPath = checkSystemCommands();
  if (antigravityPath) return antigravityPath;

  return null;
}

/**
 * Check common installation paths
 */
function checkCommonPaths(platform) {
  const homedir = os.homedir();
  let paths = [];

  switch (platform) {
    case 'darwin':
      paths = [
        '/Applications/Antigravity.app',
        '/Applications/Antigravity',
        path.join(homedir, 'Applications/Antigravity.app'),
        path.join(homedir, 'Applications/Antigravity')
      ];
      break;

    case 'linux':
      paths = [
        '/opt/antigravity',
        '/usr/local/bin/antigravity',
        '/usr/bin/antigravity',
        path.join(homedir, '.local/bin/antigravity'),
        path.join(homedir, '.antigravity')
      ];
      break;

    case 'win32':
      paths = [
        'C:\\Program Files\\Antigravity',
        'C:\\Program Files (x86)\\Antigravity',
        path.join(process.env.APPDATA || '', 'Antigravity'),
        path.join(process.env.LOCALAPPDATA || '', 'Antigravity')
      ];
      break;
  }

  for (const checkPath of paths) {
    if (fs.existsSync(checkPath)) {
      // Verify it's actually Antigravity
      if (isValidAntigravityPath(checkPath)) {
        return checkPath;
      }
    }
  }

  return null;
}

/**
 * Check PATH environment variable
 */
function checkPATH() {
  try {
    const antigravityPath = which.sync('antigravity');
    if (antigravityPath && isValidAntigravityPath(antigravityPath)) {
      return antigravityPath;
    }
  } catch (e) {
    // Not in PATH
  }

  return null;
}

/**
 * Check home directory
 */
function checkHomeDirectory(platform) {
  const homedir = os.homedir();
  const configDir = path.join(homedir, '.antigravity');

  if (fs.existsSync(configDir)) {
    const configFile = path.join(configDir, 'config.json');
    if (fs.existsSync(configFile)) {
      try {
        const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));
        if (config.installPath && fs.existsSync(config.installPath)) {
          return config.installPath;
        }
      } catch (e) {
        // Invalid config
      }
    }
  }

  return null;
}

/**
 * Check using system commands
 */
function checkSystemCommands() {
  try {
    // Try 'antigravity --version'
    const result = execSync('antigravity --version', { encoding: 'utf8' });
    if (result.includes('Antigravity')) {
      // Found it, try to get the path
      try {
        const path = execSync('which antigravity', { encoding: 'utf8' }).trim();
        return path;
      } catch (e) {
        return 'antigravity'; // Assume it's in PATH
      }
    }
  } catch (e) {
    // Command not found
  }

  return null;
}

/**
 * Verify path is valid Antigravity installation
 */
function isValidAntigravityPath(checkPath) {
  // Check for key Antigravity files/directories
  const indicators = [
    'package.json',
    'bin',
    'extensions',
    'config.json'
  ];

  // For .app files (macOS)
  if (checkPath.endsWith('.app')) {
    const contentsPath = path.join(checkPath, 'Contents');
    if (fs.existsSync(contentsPath)) {
      return true;
    }
  }

  // For regular installations
  let foundIndicators = 0;
  for (const indicator of indicators) {
    if (fs.existsSync(path.join(checkPath, indicator))) {
      foundIndicators++;
    }
  }

  return foundIndicators >= 2;
}

/**
 * Get Antigravity version
 */
function getAntigravityVersion(antigravityPath) {
  try {
    const packageJsonPath = path.join(antigravityPath, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
      return pkg.version || 'unknown';
    }

    // Try command
    const result = execSync('antigravity --version', { encoding: 'utf8' });
    return result.trim();
  } catch (e) {
    return 'unknown';
  }
}

/**
 * Get Antigravity config directory
 */
function getAntigravityConfigDir() {
  const homedir = os.homedir();
  return path.join(homedir, '.antigravity');
}

/**
 * Get Antigravity extensions directory
 */
function getAntigravityExtensionsDir(antigravityPath) {
  return path.join(antigravityPath, 'extensions');
}

module.exports = {
  findAntigravity,
  isValidAntigravityPath,
  getAntigravityVersion,
  getAntigravityConfigDir,
  getAntigravityExtensionsDir
};
