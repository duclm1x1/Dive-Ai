/**
 * useDiveCoderCLI Hook
 * Hook for executing Dive Coder CLI commands via Sync Bridge
 */

import { useState, useCallback, useRef } from 'react';
import axios, { AxiosInstance } from 'axios';

interface CommandResult {
  success: boolean;
  response?: string;
  error?: string;
  metadata?: Record<string, any>;
  artifacts?: Record<string, string>;
  evidence?: Record<string, any>;
  run_id?: string;
  timestamp?: number;
  version?: string;
}

interface CLIHookOptions {
  timeout?: number;
  retries?: number;
  verbose?: boolean;
}

export function useDiveCoderCLI(syncBridgeUrl: string = 'http://localhost:8787', options: CLIHookOptions = {}) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<CommandResult | null>(null);
  const apiRef = useRef<AxiosInstance | null>(null);

  // Initialize API client
  const getApiClient = useCallback(() => {
    if (!apiRef.current) {
      apiRef.current = axios.create({
        baseURL: syncBridgeUrl,
        timeout: options.timeout || 30000,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    }
    return apiRef.current;
  }, [syncBridgeUrl, options.timeout]);

  /**
   * Execute a CLI command
   */
  const executeCommand = useCallback(async (command: string): Promise<CommandResult> => {
    setIsLoading(true);
    setError(null);

    try {
      const api = getApiClient();

      // Parse command
      const parts = command.trim().split(/\s+(?=--)/);
      const cmd = parts[0];
      const args: Record<string, string> = {};

      // Parse arguments
      for (let i = 1; i < parts.length; i++) {
        const part = parts[i];
        if (part.startsWith('--')) {
          const [key, value] = part.substring(2).split('=');
          args[key] = value || parts[i + 1];
        }
      }

      if (options.verbose) {
        console.log('Executing command:', { cmd, args });
      }

      // Execute via Sync Bridge
      const response = await api.post('/api/cli/execute', {
        command: cmd,
        args,
        timestamp: new Date().toISOString()
      });

      const result: CommandResult = response.data;
      setLastResult(result);

      return result;
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Unknown error';
      setError(errorMessage);

      const errorResult: CommandResult = {
        success: false,
        error: errorMessage,
        timestamp: Date.now()
      };

      setLastResult(errorResult);
      return errorResult;
    } finally {
      setIsLoading(false);
    }
  }, [getApiClient, options.verbose]);

  /**
   * Get command suggestions
   */
  const getCommandSuggestions = useCallback(async (input: string): Promise<string[]> => {
    try {
      const api = getApiClient();
      const response = await api.get('/api/cli/suggestions', {
        params: { input }
      });
      return response.data.suggestions || [];
    } catch (err) {
      return [];
    }
  }, [getApiClient]);

  /**
   * Get command help
   */
  const getCommandHelp = useCallback(async (command?: string): Promise<string> => {
    try {
      const api = getApiClient();
      const response = await api.get('/api/cli/help', {
        params: { command }
      });
      return response.data.help || '';
    } catch (err) {
      return 'Help not available';
    }
  }, [getApiClient]);

  /**
   * Get available commands
   */
  const getAvailableCommands = useCallback(async (): Promise<string[]> => {
    try {
      const api = getApiClient();
      const response = await api.get('/api/cli/commands');
      return response.data.commands || [];
    } catch (err) {
      return [];
    }
  }, [getApiClient]);

  /**
   * Get command history
   */
  const getCommandHistory = useCallback(async (limit: number = 50): Promise<string[]> => {
    try {
      const api = getApiClient();
      const response = await api.get('/api/cli/history', {
        params: { limit }
      });
      return response.data.history || [];
    } catch (err) {
      return [];
    }
  }, [getApiClient]);

  /**
   * Clear command history
   */
  const clearCommandHistory = useCallback(async (): Promise<boolean> => {
    try {
      const api = getApiClient();
      await api.post('/api/cli/history/clear');
      return true;
    } catch (err) {
      return false;
    }
  }, [getApiClient]);

  /**
   * Validate command syntax
   */
  const validateCommand = useCallback(async (command: string): Promise<{ valid: boolean; error?: string }> => {
    try {
      const api = getApiClient();
      const response = await api.post('/api/cli/validate', { command });
      return response.data;
    } catch (err: any) {
      return {
        valid: false,
        error: err.message
      };
    }
  }, [getApiClient]);

  /**
   * Get command details
   */
  const getCommandDetails = useCallback(async (command: string): Promise<any> => {
    try {
      const api = getApiClient();
      const response = await api.get(`/api/cli/commands/${command}`);
      return response.data;
    } catch (err) {
      return null;
    }
  }, [getApiClient]);

  /**
   * Execute command with retry
   */
  const executeCommandWithRetry = useCallback(async (
    command: string,
    maxRetries: number = options.retries || 3
  ): Promise<CommandResult> => {
    let lastError: any;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await executeCommand(command);
      } catch (err) {
        lastError = err;
        if (attempt < maxRetries - 1) {
          // Exponential backoff
          await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
        }
      }
    }

    throw lastError;
  }, [executeCommand, options.retries]);

  /**
   * Stream command output
   */
  const streamCommand = useCallback(async (
    command: string,
    onChunk: (chunk: string) => void
  ): Promise<CommandResult> => {
    setIsLoading(true);
    setError(null);

    try {
      const api = getApiClient();

      const response = await api.post(
        '/api/cli/execute/stream',
        { command },
        {
          responseType: 'stream'
        }
      );

      return new Promise((resolve, reject) => {
        let result: CommandResult = { success: false };

        response.data.on('data', (chunk: Buffer) => {
          const text = chunk.toString();
          onChunk(text);

          try {
            const parsed = JSON.parse(text);
            if (parsed.type === 'result') {
              result = parsed.data;
            }
          } catch (e) {
            // Not JSON, just text
          }
        });

        response.data.on('end', () => {
          setLastResult(result);
          resolve(result);
        });

        response.data.on('error', (err: any) => {
          setError(err.message);
          reject(err);
        });
      });
    } catch (err: any) {
      const errorMessage = err.message || 'Stream error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [getApiClient]);

  return {
    // State
    isLoading,
    error,
    lastResult,

    // Methods
    executeCommand,
    executeCommandWithRetry,
    streamCommand,
    getCommandSuggestions,
    getCommandHelp,
    getAvailableCommands,
    getCommandHistory,
    clearCommandHistory,
    validateCommand,
    getCommandDetails
  };
}

export default useDiveCoderCLI;
