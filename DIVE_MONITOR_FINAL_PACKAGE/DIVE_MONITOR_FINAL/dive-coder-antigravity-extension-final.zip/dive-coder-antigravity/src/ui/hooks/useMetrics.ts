/**
 * useMetrics Hook
 * Real-time metrics from Sync Bridge
 */

import { useState, useEffect, useRef, useCallback } from 'react';

export interface Metrics {
  totalDuration: number;
  llmTime: number;
  toolTime: number;
  latencyP50: number;
  latencyP95: number;
  throughput: number;
  inputTokens: number;
  outputTokens: number;
  memoryUsage: number;
  cpuUsage: number;
  recentCommands: string[];
  timestamp: number;
}

interface MetricsHookOptions {
  refreshInterval?: number;
  autoConnect?: boolean;
}

export function useMetrics(
  syncBridgeUrl: string = 'http://localhost:8787',
  options: MetricsHookOptions = {}
) {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [uptime, setUptime] = useState(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(Date.now());

  const refreshInterval = options.refreshInterval || 1000;
  const autoConnect = options.autoConnect !== false;

  /**
   * Connect to WebSocket
   */
  const connect = useCallback(() => {
    try {
      const wsUrl = syncBridgeUrl.replace(/^http/, 'ws') + '/metrics';

      if (wsRef.current?.readyState === WebSocket.OPEN) {
        return;
      }

      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        setIsConnected(true);
        setError(null);
        startTimeRef.current = Date.now();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'metrics') {
            setMetrics(data.metrics);
          } else if (data.type === 'session') {
            setSessionId(data.sessionId);
          }
        } catch (e) {
          console.error('Failed to parse metrics:', e);
        }
      };

      ws.onerror = (event) => {
        setError('WebSocket error');
        setIsConnected(false);
      };

      ws.onclose = () => {
        setIsConnected(false);
        wsRef.current = null;

        // Attempt reconnect
        if (autoConnect) {
          setTimeout(connect, 3000);
        }
      };

      wsRef.current = ws;
    } catch (err: any) {
      setError(err.message);
      setIsConnected(false);
    }
  }, [syncBridgeUrl, autoConnect]);

  /**
   * Disconnect from WebSocket
   */
  const disconnect = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  }, []);

  /**
   * Fetch metrics via REST API
   */
  const fetchMetrics = useCallback(async () => {
    try {
      const response = await fetch(`${syncBridgeUrl}/api/metrics`);
      if (response.ok) {
        const data = await response.json();
        setMetrics(data.metrics);
        if (data.sessionId) {
          setSessionId(data.sessionId);
        }
      }
    } catch (err: any) {
      console.error('Failed to fetch metrics:', err);
    }
  }, [syncBridgeUrl]);

  /**
   * Update uptime
   */
  useEffect(() => {
    const interval = setInterval(() => {
      setUptime(Date.now() - startTimeRef.current);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  /**
   * Connect on mount
   */
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  /**
   * Fallback to REST API polling if WebSocket fails
   */
  useEffect(() => {
    if (!isConnected && autoConnect) {
      refreshIntervalRef.current = setInterval(fetchMetrics, refreshInterval);

      return () => {
        if (refreshIntervalRef.current) {
          clearInterval(refreshIntervalRef.current);
        }
      };
    }
  }, [isConnected, autoConnect, refreshInterval, fetchMetrics]);

  return {
    metrics,
    isConnected,
    uptime,
    sessionId,
    error,
    connect,
    disconnect,
    fetchMetrics
  };
}

export default useMetrics;
