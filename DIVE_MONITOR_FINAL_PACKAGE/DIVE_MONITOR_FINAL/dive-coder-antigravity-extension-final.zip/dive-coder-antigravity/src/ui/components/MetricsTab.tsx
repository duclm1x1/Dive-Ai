/**
 * Metrics Tab Component
 * Real-time metrics and performance monitoring
 */

import React, { useState, useEffect } from 'react';
import { useMetrics } from '../hooks/useMetrics';
import './MetricsTab.css';

interface MetricsTabProps {
  syncBridgeUrl?: string;
  theme?: 'dark' | 'light';
}

export const MetricsTab: React.FC<MetricsTabProps> = ({
  syncBridgeUrl = 'http://localhost:8787',
  theme = 'dark'
}) => {
  const { metrics, isConnected, uptime, sessionId } = useMetrics(syncBridgeUrl);
  const [refreshInterval, setRefreshInterval] = useState(1000);

  return (
    <div className={`metrics-container ${theme}`}>
      {/* Header */}
      <div className="metrics-header">
        <h2>Metrics & Performance</h2>
        <div className="metrics-controls">
          <select
            className="refresh-interval-select"
            value={refreshInterval}
            onChange={(e) => setRefreshInterval(Number(e.target.value))}
          >
            <option value={500}>500ms</option>
            <option value={1000}>1s</option>
            <option value={2000}>2s</option>
            <option value={5000}>5s</option>
          </select>
        </div>
      </div>

      {/* Status Card */}
      <div className="metrics-card status-card">
        <div className="card-title">Connection Status</div>
        <div className="status-content">
          <div className="status-item">
            <span className="status-label">Status:</span>
            <span className={`status-value ${isConnected ? 'connected' : 'disconnected'}`}>
              {isConnected ? '✓ Connected' : '✗ Disconnected'}
            </span>
          </div>
          <div className="status-item">
            <span className="status-label">Session ID:</span>
            <span className="status-value mono">{sessionId || 'N/A'}</span>
          </div>
          <div className="status-item">
            <span className="status-label">Uptime:</span>
            <span className="status-value">{formatUptime(uptime)}</span>
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="metrics-card performance-card">
        <div className="card-title">Performance Metrics</div>
        <div className="metrics-grid">
          <div className="metric-item">
            <div className="metric-label">Total Duration</div>
            <div className="metric-value">
              {metrics?.totalDuration ? `${metrics.totalDuration.toFixed(2)}s` : '—'}
            </div>
            <div className="metric-bar">
              <div
                className="metric-bar-fill"
                style={{
                  width: `${Math.min((metrics?.totalDuration || 0) / 10 * 100, 100)}%`
                }}
              ></div>
            </div>
          </div>

          <div className="metric-item">
            <div className="metric-label">LLM Time</div>
            <div className="metric-value">
              {metrics?.llmTime ? `${metrics.llmTime.toFixed(2)}s` : '—'}
            </div>
            <div className="metric-bar">
              <div
                className="metric-bar-fill llm"
                style={{
                  width: `${Math.min((metrics?.llmTime || 0) / (metrics?.totalDuration || 1) * 100, 100)}%`
                }}
              ></div>
            </div>
          </div>

          <div className="metric-item">
            <div className="metric-label">Tool Time</div>
            <div className="metric-value">
              {metrics?.toolTime ? `${metrics.toolTime.toFixed(2)}s` : '—'}
            </div>
            <div className="metric-bar">
              <div
                className="metric-bar-fill tool"
                style={{
                  width: `${Math.min((metrics?.toolTime || 0) / (metrics?.totalDuration || 1) * 100, 100)}%`
                }}
              ></div>
            </div>
          </div>

          <div className="metric-item">
            <div className="metric-label">Latency (p50)</div>
            <div className="metric-value">
              {metrics?.latencyP50 ? `${metrics.latencyP50.toFixed(0)}ms` : '—'}
            </div>
          </div>

          <div className="metric-item">
            <div className="metric-label">Latency (p95)</div>
            <div className="metric-value">
              {metrics?.latencyP95 ? `${metrics.latencyP95.toFixed(0)}ms` : '—'}
            </div>
          </div>

          <div className="metric-item">
            <div className="metric-label">Throughput</div>
            <div className="metric-value">
              {metrics?.throughput ? `${metrics.throughput.toFixed(0)} ops/s` : '—'}
            </div>
          </div>
        </div>
      </div>

      {/* Token Usage */}
      <div className="metrics-card token-card">
        <div className="card-title">Token Usage</div>
        <div className="token-content">
          <div className="token-item">
            <span className="token-label">Input Tokens:</span>
            <span className="token-value">{metrics?.inputTokens || 0}</span>
          </div>
          <div className="token-item">
            <span className="token-label">Output Tokens:</span>
            <span className="token-value">{metrics?.outputTokens || 0}</span>
          </div>
          <div className="token-item">
            <span className="token-label">Total Tokens:</span>
            <span className="token-value">
              {(metrics?.inputTokens || 0) + (metrics?.outputTokens || 0)}
            </span>
          </div>
          <div className="token-bar">
            <div className="token-bar-label">Token Usage</div>
            <div className="token-bar-container">
              <div
                className="token-bar-fill input"
                style={{
                  width: `${(metrics?.inputTokens || 0) / ((metrics?.inputTokens || 0) + (metrics?.outputTokens || 0) || 1) * 100}%`
                }}
                title={`Input: ${metrics?.inputTokens || 0}`}
              ></div>
              <div
                className="token-bar-fill output"
                style={{
                  width: `${(metrics?.outputTokens || 0) / ((metrics?.inputTokens || 0) + (metrics?.outputTokens || 0) || 1) * 100}%`
                }}
                title={`Output: ${metrics?.outputTokens || 0}`}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Resource Usage */}
      <div className="metrics-card resource-card">
        <div className="card-title">Resource Usage</div>
        <div className="resource-content">
          <div className="resource-item">
            <span className="resource-label">Memory:</span>
            <span className="resource-value">
              {metrics?.memoryUsage ? `${(metrics.memoryUsage / 1024 / 1024).toFixed(1)}MB` : '—'}
            </span>
            <div className="resource-bar">
              <div
                className="resource-bar-fill"
                style={{
                  width: `${Math.min((metrics?.memoryUsage || 0) / (512 * 1024 * 1024) * 100, 100)}%`
                }}
              ></div>
            </div>
          </div>

          <div className="resource-item">
            <span className="resource-label">CPU:</span>
            <span className="resource-value">
              {metrics?.cpuUsage ? `${metrics.cpuUsage.toFixed(1)}%` : '—'}
            </span>
            <div className="resource-bar">
              <div
                className="resource-bar-fill cpu"
                style={{
                  width: `${Math.min(metrics?.cpuUsage || 0, 100)}%`
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Commands */}
      <div className="metrics-card commands-card">
        <div className="card-title">Recent Commands</div>
        <div className="commands-list">
          {metrics?.recentCommands && metrics.recentCommands.length > 0 ? (
            metrics.recentCommands.map((cmd, index) => (
              <div key={index} className="command-item">
                <span className="command-index">{index + 1}.</span>
                <span className="command-text">{cmd}</span>
              </div>
            ))
          ) : (
            <div className="no-commands">No commands executed yet</div>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * Format uptime
 */
function formatUptime(ms: number): string {
  if (!ms) return '0s';

  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

export default MetricsTab;
