/**
 * CLI Input Component
 * Integrated CLI interface for Dive Coder in Antigravity tab
 */

import React, { useState, useRef, useEffect } from 'react';
import { useDiveCoderCLI } from '../hooks/useDiveCoderCLI';
import './CLIInput.css';

interface CLIInputProps {
  onCommandExecute?: (command: string, result: any) => void;
  syncBridgeUrl?: string;
  theme?: 'dark' | 'light';
}

export const CLIInput: React.FC<CLIInputProps> = ({
  onCommandExecute,
  syncBridgeUrl = 'http://localhost:8787',
  theme = 'dark'
}) => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isExecuting, setIsExecuting] = useState(false);
  const [output, setOutput] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);
  const { executeCommand, getCommandSuggestions } = useDiveCoderCLI(syncBridgeUrl);

  // Command suggestions
  const AVAILABLE_COMMANDS = [
    'status',
    'process --input ""',
    'component --name dive_engine',
    'component --name monitoring',
    'component --name rag',
    'sync-status',
    'sync-pull --type events --limit 100',
    'sync-health',
    'help'
  ];

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInput(value);
    setHistoryIndex(-1);

    // Get suggestions
    if (value.length > 0) {
      const filtered = AVAILABLE_COMMANDS.filter(cmd =>
        cmd.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  // Handle key press
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleExecuteCommand();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      handleHistoryUp();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      handleHistoryDown();
    } else if (e.key === 'Tab' && suggestions.length > 0) {
      e.preventDefault();
      setInput(suggestions[0]);
      setShowSuggestions(false);
    }
  };

  // Handle history navigation
  const handleHistoryUp = () => {
    if (history.length === 0) return;
    const newIndex = historyIndex + 1;
    if (newIndex < history.length) {
      setHistoryIndex(newIndex);
      setInput(history[history.length - 1 - newIndex]);
    }
  };

  const handleHistoryDown = () => {
    if (historyIndex <= 0) {
      setHistoryIndex(-1);
      setInput('');
    } else {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setInput(history[history.length - 1 - newIndex]);
    }
  };

  // Execute command
  const handleExecuteCommand = async () => {
    if (!input.trim()) return;

    setIsExecuting(true);
    setShowSuggestions(false);

    try {
      // Add to history
      setHistory([...history, input]);

      // Add to output
      const commandOutput = {
        type: 'command',
        command: input,
        timestamp: new Date().toLocaleTimeString()
      };
      setOutput(prev => [...prev, commandOutput]);

      // Execute command
      const result = await executeCommand(input);

      // Add result to output
      const resultOutput = {
        type: 'result',
        data: result,
        timestamp: new Date().toLocaleTimeString(),
        success: result.success !== false
      };
      setOutput(prev => [...prev, resultOutput]);

      // Callback
      if (onCommandExecute) {
        onCommandExecute(input, result);
      }

      // Clear input
      setInput('');
    } catch (error: any) {
      // Add error to output
      const errorOutput = {
        type: 'error',
        error: error.message,
        timestamp: new Date().toLocaleTimeString()
      };
      setOutput(prev => [...prev, errorOutput]);
    } finally {
      setIsExecuting(false);
    }
  };

  // Scroll to bottom on new output
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  // Handle suggestion click
  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    setShowSuggestions(false);
    inputRef.current?.focus();
  };

  // Clear output
  const handleClearOutput = () => {
    setOutput([]);
  };

  // Copy output
  const handleCopyOutput = () => {
    const text = output
      .map(item => {
        if (item.type === 'command') {
          return `$ ${item.command}`;
        } else if (item.type === 'result') {
          return JSON.stringify(item.data, null, 2);
        } else if (item.type === 'error') {
          return `Error: ${item.error}`;
        }
        return '';
      })
      .join('\n');

    navigator.clipboard.writeText(text);
  };

  // Export output
  const handleExportOutput = () => {
    const text = output
      .map(item => {
        if (item.type === 'command') {
          return `$ ${item.command}`;
        } else if (item.type === 'result') {
          return JSON.stringify(item.data, null, 2);
        } else if (item.type === 'error') {
          return `Error: ${item.error}`;
        }
        return '';
      })
      .join('\n');

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dive-coder-output-${new Date().toISOString()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`cli-input-container ${theme}`}>
      <div className="cli-header">
        <h2>Dive Coder CLI</h2>
        <div className="cli-status">
          <span className={`status-indicator ${isExecuting ? 'executing' : 'ready'}`}></span>
          <span className="status-text">
            {isExecuting ? 'Executing...' : 'Ready'}
          </span>
        </div>
      </div>

      {/* Output Panel */}
      <div className="cli-output" ref={outputRef}>
        {output.length === 0 ? (
          <div className="cli-welcome">
            <p>Welcome to Dive Coder V15.3</p>
            <p className="cli-hint">Type a command and press Enter</p>
            <p className="cli-hint">Use ↑↓ for history, Tab for autocomplete</p>
          </div>
        ) : (
          output.map((item, index) => (
            <div key={index} className={`cli-output-item ${item.type}`}>
              {item.type === 'command' && (
                <div className="cli-command">
                  <span className="cli-prompt">$</span>
                  <span className="cli-command-text">{item.command}</span>
                  <span className="cli-timestamp">{item.timestamp}</span>
                </div>
              )}
              {item.type === 'result' && (
                <div className={`cli-result ${item.success ? 'success' : 'error'}`}>
                  <pre>{JSON.stringify(item.data, null, 2)}</pre>
                </div>
              )}
              {item.type === 'error' && (
                <div className="cli-error">
                  <span className="cli-error-icon">⚠</span>
                  <span className="cli-error-text">{item.error}</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Suggestions */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="cli-suggestions">
          {suggestions.map((suggestion, index) => (
            <div
              key={index}
              className="cli-suggestion-item"
              onClick={() => handleSuggestionClick(suggestion)}
            >
              <span className="cli-suggestion-text">{suggestion}</span>
            </div>
          ))}
        </div>
      )}

      {/* Input Area */}
      <div className="cli-input-area">
        <span className="cli-prompt">$</span>
        <input
          ref={inputRef}
          type="text"
          className="cli-input-field"
          value={input}
          onChange={handleInputChange}
          onKeyDown={handleKeyPress}
          placeholder="Enter command (e.g., status, process --input '...')"
          disabled={isExecuting}
          autoFocus
        />
      </div>

      {/* Controls */}
      <div className="cli-controls">
        <button
          className="cli-button cli-button-clear"
          onClick={handleClearOutput}
          title="Clear output"
        >
          Clear
        </button>
        <button
          className="cli-button cli-button-copy"
          onClick={handleCopyOutput}
          title="Copy output"
          disabled={output.length === 0}
        >
          Copy
        </button>
        <button
          className="cli-button cli-button-export"
          onClick={handleExportOutput}
          title="Export output"
          disabled={output.length === 0}
        >
          Export
        </button>
      </div>

      {/* Command History */}
      {history.length > 0 && (
        <div className="cli-history-info">
          <span>History: {history.length} commands</span>
        </div>
      )}
    </div>
  );
};

export default CLIInput;
