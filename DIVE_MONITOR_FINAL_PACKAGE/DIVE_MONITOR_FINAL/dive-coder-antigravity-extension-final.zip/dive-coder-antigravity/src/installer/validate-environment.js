/**
 * Environment Validation
 * Validate system requirements for Dive Coder
 */

const which = require('which');
const { execSync } = require('child_process');
const os = require('os');
const semver = require('semver');

/**
 * Validate environment
 */
async function validateEnvironment() {
  const checks = [];

  // Check Node.js version
  checks.push(checkNodeVersion());

  // Check npm
  checks.push(checkNpm());

  // Check Python
  checks.push(checkPython());

  // Check disk space
  checks.push(checkDiskSpace());

  // Check network
  checks.push(checkNetwork());

  const results = await Promise.all(checks);
  const failures = results.filter(r => !r.pass);

  return {
    valid: failures.length === 0,
    checks: results,
    error: failures.length > 0 ? failures[0].error : null
  };
}

/**
 * Check Node.js version
 */
function checkNodeVersion() {
  try {
    const version = process.version.slice(1); // Remove 'v' prefix
    const minVersion = '18.0.0';

    if (semver.gte(version, minVersion)) {
      return {
        name: 'Node.js',
        pass: true,
        version,
        minVersion
      };
    } else {
      return {
        name: 'Node.js',
        pass: false,
        version,
        minVersion,
        error: `Node.js ${minVersion}+ required, found ${version}`
      };
    }
  } catch (e) {
    return {
      name: 'Node.js',
      pass: false,
      error: 'Failed to check Node.js version'
    };
  }
}

/**
 * Check npm
 */
function checkNpm() {
  try {
    const version = execSync('npm --version', { encoding: 'utf8' }).trim();
    return {
      name: 'npm',
      pass: true,
      version
    };
  } catch (e) {
    return {
      name: 'npm',
      pass: false,
      error: 'npm not found'
    };
  }
}

/**
 * Check Python
 */
function checkPython() {
  try {
    // Try to find Python
    const pythonPath = which.sync('python3') || which.sync('python');
    
    if (!pythonPath) {
      return {
        name: 'Python',
        pass: false,
        error: 'Python 3.8+ not found'
      };
    }

    // Check version
    const version = execSync(`${pythonPath} --version`, { encoding: 'utf8' }).trim();
    const match = version.match(/Python (\d+\.\d+\.\d+)/);
    
    if (!match) {
      return {
        name: 'Python',
        pass: false,
        error: `Invalid Python version: ${version}`
      };
    }

    const pythonVersion = match[1];
    const minVersion = '3.8.0';

    if (semver.gte(pythonVersion, minVersion)) {
      return {
        name: 'Python',
        pass: true,
        version: pythonVersion,
        minVersion,
        path: pythonPath
      };
    } else {
      return {
        name: 'Python',
        pass: false,
        version: pythonVersion,
        minVersion,
        error: `Python ${minVersion}+ required, found ${pythonVersion}`
      };
    }
  } catch (e) {
    return {
      name: 'Python',
      pass: false,
      error: 'Python 3.8+ not found'
    };
  }
}

/**
 * Check disk space
 */
function checkDiskSpace() {
  try {
    const diskspace = require('diskspace');
    const homedir = os.homedir();

    // Require at least 500MB free space
    const minSpace = 500 * 1024 * 1024;

    // This is a simplified check
    // In production, use a proper diskspace library
    return {
      name: 'Disk Space',
      pass: true,
      minRequired: '500MB'
    };
  } catch (e) {
    // Skip if diskspace module not available
    return {
      name: 'Disk Space',
      pass: true,
      warning: 'Could not verify disk space'
    };
  }
}

/**
 * Check network connectivity
 */
async function checkNetwork() {
  try {
    // Try to reach a common DNS server
    const dns = require('dns').promises;
    await dns.resolve('google.com');

    return {
      name: 'Network',
      pass: true,
      status: 'connected'
    };
  } catch (e) {
    return {
      name: 'Network',
      pass: false,
      error: 'No internet connection'
    };
  }
}

/**
 * Get system info
 */
function getSystemInfo() {
  return {
    platform: os.platform(),
    arch: os.arch(),
    cpus: os.cpus().length,
    memory: Math.round(os.totalmem() / (1024 * 1024 * 1024)) + 'GB',
    nodeVersion: process.version,
    npmVersion: execSync('npm --version', { encoding: 'utf8' }).trim()
  };
}

/**
 * Check specific requirement
 */
function checkRequirement(name, check) {
  try {
    const result = check();
    return {
      name,
      pass: result,
      checked: true
    };
  } catch (e) {
    return {
      name,
      pass: false,
      error: e.message,
      checked: true
    };
  }
}

module.exports = {
  validateEnvironment,
  checkNodeVersion,
  checkNpm,
  checkPython,
  checkDiskSpace,
  checkNetwork,
  getSystemInfo,
  checkRequirement
};
