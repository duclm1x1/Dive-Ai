/**
 * Launch Antigravity with Dive Coder Extension
 */

const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs-extra');

/**
 * Launch Antigravity with Dive Coder extension
 */
async function launchAntigravity(antigravityPath, options = {}) {
  const platform = os.platform();
  const extensionName = options.extension || 'dive-coder';
  const syncBridgeUrl = options.syncBridgeUrl || 'http://localhost:8787';
  const openTab = options.openTab || 'dive-coder';

  // Prepare environment variables
  const env = {
    ...process.env,
    DIVE_CODER_ENABLED: 'true',
    DIVE_CODER_EXTENSION: extensionName,
    DIVE_CODER_SYNC_BRIDGE: syncBridgeUrl,
    DIVE_CODER_OPEN_TAB: openTab
  };

  try {
    // Get the executable path based on platform
    const executablePath = getAntigravityExecutable(antigravityPath, platform);

    if (!fs.existsSync(executablePath)) {
      throw new Error(`Antigravity executable not found at ${executablePath}`);
    }

    // Launch Antigravity
    const antigravityProcess = spawn(executablePath, [], {
      env,
      stdio: 'inherit',
      detached: false
    });

    // Handle process events
    antigravityProcess.on('error', (err) => {
      console.error('Failed to launch Antigravity:', err.message);
      process.exit(1);
    });

    antigravityProcess.on('exit', (code) => {
      if (code !== 0) {
        console.error(`Antigravity exited with code ${code}`);
        process.exit(code);
      }
    });

    // Keep the process running
    return new Promise((resolve, reject) => {
      antigravityProcess.on('exit', (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(`Antigravity exited with code ${code}`));
        }
      });
    });

  } catch (error) {
    throw new Error(`Failed to launch Antigravity: ${error.message}`);
  }
}

/**
 * Get Antigravity executable path
 */
function getAntigravityExecutable(antigravityPath, platform) {
  switch (platform) {
    case 'darwin':
      // macOS - check for .app bundle
      if (antigravityPath.endsWith('.app')) {
        return path.join(antigravityPath, 'Contents', 'MacOS', 'Antigravity');
      }
      return path.join(antigravityPath, 'bin', 'antigravity');

    case 'linux':
      // Linux
      if (antigravityPath.includes('bin')) {
        return antigravityPath;
      }
      return path.join(antigravityPath, 'bin', 'antigravity');

    case 'win32':
      // Windows
      if (antigravityPath.endsWith('.exe')) {
        return antigravityPath;
      }
      return path.join(antigravityPath, 'bin', 'antigravity.exe');

    default:
      return antigravityPath;
  }
}

/**
 * Launch Antigravity in background
 */
async function launchAntigravityBackground(antigravityPath, options = {}) {
  const platform = os.platform();
  const executablePath = getAntigravityExecutable(antigravityPath, platform);

  if (!fs.existsSync(executablePath)) {
    throw new Error(`Antigravity executable not found at ${executablePath}`);
  }

  const env = {
    ...process.env,
    DIVE_CODER_ENABLED: 'true',
    DIVE_CODER_SYNC_BRIDGE: options.syncBridgeUrl || 'http://localhost:8787'
  };

  // Spawn detached process
  const antigravityProcess = spawn(executablePath, [], {
    env,
    stdio: 'ignore',
    detached: true
  });

  // Unref to allow parent process to exit
  antigravityProcess.unref();

  return {
    pid: antigravityProcess.pid,
    running: true
  };
}

/**
 * Check if Antigravity is running
 */
function isAntigravityRunning() {
  try {
    const psList = require('ps-list');
    return psList().then(processes => {
      return processes.some(p => 
        p.name.toLowerCase().includes('antigravity') ||
        p.cmd.toLowerCase().includes('antigravity')
      );
    });
  } catch (e) {
    return false;
  }
}

/**
 * Kill Antigravity process
 */
function killAntigravity() {
  try {
    const platform = os.platform();
    if (platform === 'win32') {
      require('child_process').execSync('taskkill /IM antigravity.exe /F', { stdio: 'ignore' });
    } else {
      require('child_process').execSync('pkill -f antigravity', { stdio: 'ignore' });
    }
    return true;
  } catch (e) {
    return false;
  }
}

module.exports = {
  launchAntigravity,
  launchAntigravityBackground,
  getAntigravityExecutable,
  isAntigravityRunning,
  killAntigravity
};
