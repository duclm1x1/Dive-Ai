/**
 * Python Dependencies Installer
 * Install required Python packages for Dive Coder
 */

const { execSync } = require('child_process');
const which = require('which');
const os = require('os');
const path = require('path');

const REQUIRED_PACKAGES = [
  'websockets>=12.0',
  'requests>=2.31.0',
  'fastapi>=0.104.0',
  'uvicorn>=0.24.0',
  'pydantic>=2.5.0'
];

const OPTIONAL_PACKAGES = [
  'numpy>=1.24.0',
  'pandas>=2.0.0',
  'scikit-learn>=1.3.0'
];

/**
 * Install Python dependencies
 */
async function installPythonDeps(options = {}) {
  const pythonPath = options.pythonPath || getPythonPath();
  
  if (!pythonPath) {
    throw new Error('Python not found. Please install Python 3.8+');
  }

  // Check Python version
  const version = getPythonVersion(pythonPath);
  if (!isValidPythonVersion(version)) {
    throw new Error(`Python ${version} is not supported. Please use Python 3.8+`);
  }

  // Install required packages
  for (const pkg of REQUIRED_PACKAGES) {
    await installPackage(pythonPath, pkg, options);
  }

  // Install optional packages (don't fail if they fail)
  for (const pkg of OPTIONAL_PACKAGES) {
    try {
      await installPackage(pythonPath, pkg, { ...options, optional: true });
    } catch (e) {
      // Ignore optional package failures
    }
  }

  return {
    pythonPath,
    pythonVersion: version,
    packagesInstalled: REQUIRED_PACKAGES.length
  };
}

/**
 * Get Python executable path
 */
function getPythonPath(customPath) {
  if (customPath) {
    try {
      execSync(`${customPath} --version`, { stdio: 'pipe' });
      return customPath;
    } catch (e) {
      // Not valid
    }
  }

  // Try common Python commands
  const pythonCommands = [
    'python3',
    'python',
    'python3.11',
    'python3.10',
    'python3.9',
    'python3.8'
  ];

  for (const cmd of pythonCommands) {
    try {
      which.sync(cmd);
      return cmd;
    } catch (e) {
      // Not found
    }
  }

  return null;
}

/**
 * Get Python version
 */
function getPythonVersion(pythonPath) {
  try {
    const output = execSync(`${pythonPath} --version`, { encoding: 'utf8' });
    // Output: "Python 3.11.0"
    const match = output.match(/Python (\d+\.\d+\.\d+)/);
    return match ? match[1] : 'unknown';
  } catch (e) {
    return 'unknown';
  }
}

/**
 * Check if Python version is valid
 */
function isValidPythonVersion(version) {
  const parts = version.split('.');
  if (parts.length < 2) return false;

  const major = parseInt(parts[0]);
  const minor = parseInt(parts[1]);

  // Require Python 3.8+
  return major > 3 || (major === 3 && minor >= 8);
}

/**
 * Install a single package
 */
async function installPackage(pythonPath, packageSpec, options = {}) {
  try {
    // Try pip install
    const command = `${pythonPath} -m pip install ${packageSpec}`;
    
    if (options.verbose) {
      console.log(`Installing: ${packageSpec}`);
    }

    execSync(command, {
      stdio: options.verbose ? 'inherit' : 'pipe',
      env: {
        ...process.env,
        PIP_NO_INPUT: '1'
      }
    });

    return true;
  } catch (error) {
    if (options.optional) {
      console.warn(`Optional package failed: ${packageSpec}`);
      return false;
    }
    throw new Error(`Failed to install ${packageSpec}: ${error.message}`);
  }
}

/**
 * Check if package is installed
 */
function isPackageInstalled(pythonPath, packageName) {
  try {
    execSync(`${pythonPath} -c "import ${packageName}"`, { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Get installed packages
 */
function getInstalledPackages(pythonPath) {
  try {
    const output = execSync(`${pythonPath} -m pip list --format json`, { encoding: 'utf8' });
    return JSON.parse(output);
  } catch (e) {
    return [];
  }
}

/**
 * Upgrade pip
 */
function upgradePip(pythonPath) {
  try {
    execSync(`${pythonPath} -m pip install --upgrade pip`, { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Create virtual environment
 */
function createVirtualEnv(pythonPath, envPath) {
  try {
    execSync(`${pythonPath} -m venv ${envPath}`, { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Get virtual environment Python path
 */
function getVenvPythonPath(envPath) {
  const platform = os.platform();
  if (platform === 'win32') {
    return path.join(envPath, 'Scripts', 'python.exe');
  }
  return path.join(envPath, 'bin', 'python');
}

module.exports = {
  installPythonDeps,
  getPythonPath,
  getPythonVersion,
  isValidPythonVersion,
  installPackage,
  isPackageInstalled,
  getInstalledPackages,
  upgradePip,
  createVirtualEnv,
  getVenvPythonPath,
  REQUIRED_PACKAGES,
  OPTIONAL_PACKAGES
};
