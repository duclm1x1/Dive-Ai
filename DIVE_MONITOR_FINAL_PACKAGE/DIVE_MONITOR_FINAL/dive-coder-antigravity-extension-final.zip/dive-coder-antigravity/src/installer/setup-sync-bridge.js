/**
 * Sync Bridge Setup
 * Initialize and start the Sync Bridge server
 */

const path = require('path');
const fs = require('fs-extra');
const { spawn } = require('child_process');
const os = require('os');
const net = require('net');

let syncBridgeProcess = null;
let syncBridgePort = 8787;

/**
 * Setup and start Sync Bridge
 */
async function setupSyncBridge(options = {}) {
  const port = options.port || syncBridgePort;
  const configDir = getSyncBridgeConfigDir();

  // Ensure config directory exists
  await fs.ensureDir(configDir);

  // Create config file
  const config = {
    port,
    version: '1.0.0',
    environment: options.environment || 'production',
    logLevel: options.logLevel || 'info',
    maxSessions: options.maxSessions || 100,
    eventBufferSize: options.eventBufferSize || 1000,
    corsOrigins: options.corsOrigins || ['*']
  };

  const configPath = path.join(configDir, 'sync-bridge-config.json');
  await fs.writeJSON(configPath, config, { spaces: 2 });

  // Check if port is available
  const portAvailable = await isPortAvailable(port);
  if (!portAvailable) {
    throw new Error(`Port ${port} is already in use`);
  }

  // Start Sync Bridge server
  await startSyncBridgeServer(port, configPath);

  return {
    port,
    configPath,
    configDir,
    status: 'running'
  };
}

/**
 * Start Sync Bridge server process
 */
async function startSyncBridgeServer(port, configPath) {
  return new Promise((resolve, reject) => {
    const serverScript = path.join(__dirname, '../server/sync-bridge.js');

    // Ensure server script exists
    if (!fs.existsSync(serverScript)) {
      return reject(new Error('Sync Bridge server script not found'));
    }

    // Start the server
    syncBridgeProcess = spawn('node', [serverScript], {
      env: {
        ...process.env,
        PORT: port,
        CONFIG_PATH: configPath,
        NODE_ENV: 'production'
      },
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: false
    });

    let output = '';
    let errorOutput = '';

    // Listen for output
    syncBridgeProcess.stdout.on('data', (data) => {
      output += data.toString();
      if (output.includes('Server running')) {
        resolve();
      }
    });

    syncBridgeProcess.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });

    // Handle process errors
    syncBridgeProcess.on('error', (err) => {
      reject(new Error(`Failed to start Sync Bridge: ${err.message}`));
    });

    syncBridgeProcess.on('exit', (code) => {
      if (code !== 0) {
        reject(new Error(`Sync Bridge exited with code ${code}: ${errorOutput}`));
      }
    });

    // Timeout after 10 seconds
    setTimeout(() => {
      reject(new Error('Sync Bridge startup timeout'));
    }, 10000);
  });
}

/**
 * Check if port is available
 */
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();

    server.once('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        resolve(false);
      } else {
        resolve(false);
      }
    });

    server.once('listening', () => {
      server.close();
      resolve(true);
    });

    server.listen(port, '127.0.0.1');
  });
}

/**
 * Stop Sync Bridge server
 */
function stopSyncBridgeServer() {
  if (syncBridgeProcess) {
    syncBridgeProcess.kill();
    syncBridgeProcess = null;
  }
}

/**
 * Get Sync Bridge config directory
 */
function getSyncBridgeConfigDir() {
  const homedir = os.homedir();
  return path.join(homedir, '.dive-coder', 'sync-bridge');
}

/**
 * Get Sync Bridge status
 */
async function getSyncBridgeStatus(port = syncBridgePort) {
  try {
    const response = await fetch(`http://localhost:${port}/health`);
    if (response.ok) {
      const data = await response.json();
      return {
        running: true,
        status: data.status,
        sessions: data.sessions,
        uptime: data.uptime
      };
    }
  } catch (e) {
    // Server not running
  }

  return {
    running: false,
    status: 'offline'
  };
}

/**
 * Get Sync Bridge logs
 */
function getSyncBridgeLogs(lines = 100) {
  const logDir = path.join(getSyncBridgeConfigDir(), 'logs');
  const logFile = path.join(logDir, 'sync-bridge.log');

  if (!fs.existsSync(logFile)) {
    return [];
  }

  try {
    const content = fs.readFileSync(logFile, 'utf8');
    return content.split('\n').slice(-lines);
  } catch (e) {
    return [];
  }
}

/**
 * Clear Sync Bridge cache
 */
async function clearSyncBridgeCache() {
  const configDir = getSyncBridgeConfigDir();
  const cacheDir = path.join(configDir, 'cache');

  if (fs.existsSync(cacheDir)) {
    await fs.remove(cacheDir);
  }

  return true;
}

module.exports = {
  setupSyncBridge,
  startSyncBridgeServer,
  stopSyncBridgeServer,
  isPortAvailable,
  getSyncBridgeStatus,
  getSyncBridgeLogs,
  getSyncBridgeConfigDir,
  clearSyncBridgeCache
};
