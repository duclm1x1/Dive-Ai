# Dive Coder Antigravity Extension - UI Design Specification

## 🎨 Visual Overview

The Dive Coder extension integrates seamlessly into Antigravity with three main tabs: **CLI**, **Metrics**, and **History**. The design follows modern IDE aesthetics with a dark theme, professional typography, and intuitive layouts.

---

## 📱 Tab 1: CLI Interface

### Layout Structure

```
┌─────────────────────────────────────────────────────────┐
│  🤿 Dive Coder CLI                    🟢 Ready          │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  $ status                                    [14:30:01] │
│  {                                                      │
│    "status": "active",                                  │
│    "version": "1.2.4",                                  │
│    "modules": {                                         │
│      "antigravity": "loaded",                           │
│      "dive_assist": "initializing"                      │
│    },                                                   │
│    "environment": "production",                         │
│    "uptime": "3d 14h 22m"                              │
│  }                                                      │
│                                                         │
│  $ process --input "Review code"             [14:30:15] │
│  [PROCESSING] Input: "Review code"                      │
│  > Analyzing file structure...                          │
│  > Detecting language: Python                           │
│  > Checking compliance with Antigravity guidelines...   │
│    - Found 3 potential issues.                          │
│    - Suggesting optimizations.                          │
│  > Generating report...                                 │
│  [COMPLETE] Report generated at ./output/review.txt     │
│                                                         │
│  ┌─────────────────────────────────────────────┐       │
│  │ status                                      │       │
│  │ process --input                             │       │
│  │ component --name                            │       │
│  │ analyze --depth                             │       │
│  │ config --set                                │       │
│  └─────────────────────────────────────────────┘       │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  $ |Enter command...                                    │
├─────────────────────────────────────────────────────────┤
│  [Clear]  [Copy]  [Export]                              │
└─────────────────────────────────────────────────────────┘
```

### Design Elements

#### Header
- **Background:** `#252526`
- **Title:** "Dive Coder CLI" with diving mask icon (🤿)
- **Status Indicator:** 
  - Green dot (🟢) + "Ready" when idle
  - Orange dot (🟠) + "Executing..." when running
- **Font:** 14px, Semi-bold

#### Output Area
- **Background:** `#1e1e1e` (dark gray)
- **Text Color:** `#e0e0e0` (light gray)
- **Scrollable:** Yes, with custom scrollbar
- **Padding:** 12px 16px

#### Command Display
- **Prompt:** `$` in cyan `#4ec9b0`
- **Command Text:** White `#e0e0e0`
- **Timestamp:** Gray `#6a6a6a`, right-aligned, 11px

#### JSON Output
- **Syntax Highlighting:**
  - Keys: Orange `#ce9178`
  - Strings: Green `#4ec9b0`
  - Numbers: Blue `#569cd6`
  - Booleans: Teal `#4fc1ff`
  - Brackets: White `#e0e0e0`

#### Process Output
- **[INFO]:** Blue `#569cd6`
- **[SUCCESS]:** Green `#4ec9b0`
- **[WARN]:** Orange `#f4a261`
- **[ERROR]:** Red `#f48771`
- **[COMPLETE]:** Teal `#4ec9b0`

#### Autocomplete Dropdown
- **Background:** `#252526`
- **Border:** `#3e3e42`
- **Hover:** `#3e3e42`
- **Text:** `#e0e0e0`
- **Highlight:** Teal `#4ec9b0`
- **Position:** Above input field
- **Max Height:** 150px, scrollable

#### Input Area
- **Background:** `#1e1e1e`
- **Border Top:** 1px solid `#3e3e42`
- **Prompt:** `$` in cyan `#4ec9b0`
- **Input Field:**
  - Background: Transparent
  - Text: `#e0e0e0`
  - Placeholder: `#6a6a6a`
  - Caret: Teal `#4ec9b0`
  - Font: Monospace (Fira Code, Courier New)

#### Control Buttons
- **Background:** `#3e3e42`
- **Text:** `#e0e0e0`
- **Border:** 1px solid `#555`
- **Hover:** Teal `#4ec9b0` background, white text
- **Padding:** 6px 12px
- **Border Radius:** 4px
- **Gap:** 8px

### Interactions

1. **Typing:**
   - Shows autocomplete dropdown after 1 character
   - Tab key selects first suggestion
   - Enter key executes command

2. **History Navigation:**
   - ↑ key: Previous command
   - ↓ key: Next command
   - Cycles through command history

3. **Output:**
   - Auto-scrolls to bottom on new output
   - Syntax highlighting for JSON
   - Color-coded status messages

4. **Buttons:**
   - **Clear:** Clears all output
   - **Copy:** Copies output to clipboard
   - **Export:** Downloads output as .txt file

---

## 📊 Tab 2: Metrics Dashboard

### Layout Structure

```
┌─────────────────────────────────────────────────────────┐
│  Metrics & Performance          [Refresh Interval ▼ 1s] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────┐  ┌──────────────────────────┐ │
│  │ Connection Status   │  │ Performance Metrics      │ │
│  │                     │  │                          │ │
│  │  ✓ Connected        │  │  Total Duration: 1.23s   │ │
│  │  Session: 0x4A9F2B7E│  │  ████████░░ 70%          │ │
│  │                     │  │                          │ │
│  │  Uptime: 2h 15m     │  │  LLM Time: 0.89s         │ │
│  │                     │  │  ████████░░              │ │
│  └─────────────────────┘  │                          │ │
│                           │  Tool Time: 0.34s        │ │
│  ┌─────────────────────┐  │  ███░░░░░░░              │ │
│  │ Token Usage         │  │                          │ │
│  │                     │  │  Latency p50: 45ms       │ │
│  │  Input: 2,450       │  │  Latency p95: 120ms      │ │
│  │  Output: 1,200      │  │  Throughput: 85 ops/s    │ │
│  │  Total: 3,650       │  └──────────────────────────┘ │
│  │                     │                               │
│  │  ████████░░░░░░░░   │  ┌──────────────────────────┐ │
│  │  (67% input)        │  │ Resource Usage           │ │
│  └─────────────────────┘  │                          │ │
│                           │  Memory: 450 MB / 1.2 GB │ │
│  ┌─────────────────────┐  │  ███████░░░ 37%          │ │
│  │ Recent Commands     │  │                          │ │
│  │                     │  │  CPU: 12% / 4 Cores      │ │
│  │  1. status          │  │  ██░░░░░░░░ 12%          │ │
│  │  2. process --input │  └──────────────────────────┘ │
│  │  3. component --name│                               │
│  │  4. sync-status     │                               │
│  │  5. sync-pull       │                               │
│  └─────────────────────┘                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Design Elements

#### Header
- **Background:** `#252526`
- **Title:** "Metrics & Performance" with 📊 icon
- **Refresh Dropdown:** 
  - Options: 500ms, 1s, 2s, 5s
  - Background: `#3e3e42`
  - Border: 1px solid `#555`

#### Cards
- **Background:** `#252526`
- **Border:** 1px solid `#3e3e42`
- **Border Radius:** 8px
- **Padding:** 16px
- **Gap:** 16px
- **Shadow:** 0 2px 8px rgba(0,0,0,0.3)

#### Card Titles
- **Color:** Teal `#4ec9b0`
- **Font:** 14px, Semi-bold
- **Margin Bottom:** 12px
- **Icon:** Small icon next to title

#### Connection Status Card
- **Checkmark:** Green `#4ec9b0`, large (24px)
- **Status Text:** "Connected" in white
- **Session ID:** Monospace font, gray `#858585`
- **Uptime:** White, 16px

#### Performance Metrics Card
- **Grid Layout:** 3 columns, 2 rows
- **Metric Boxes:**
  - Label: Gray `#858585`, 12px
  - Value: Teal `#4ec9b0`, 18px, Bold
  - Progress Bar: 4px height, rounded
    - Background: `#3e3e42`
    - Fill: Teal `#4ec9b0` (duration), Orange `#f4a261` (LLM), Red `#e76f51` (tool)

#### Token Usage Card
- **Labels:** Gray `#858585`, 13px
- **Values:** Teal `#4ec9b0`, 16px, Bold
- **Stacked Bar:**
  - Height: 6px
  - Input: Teal `#4ec9b0`
  - Output: Orange `#f4a261`
  - No gap between segments

#### Resource Usage Card
- **Resource Items:**
  - Label: Gray `#858585`
  - Value: Teal `#4ec9b0`, Bold
  - Bar: 6px height
    - Memory: Teal `#4ec9b0`
    - CPU: Orange `#e76f51`

#### Recent Commands Card
- **List Style:** Numbered
- **Items:**
  - Background: `#1e1e1e`
  - Padding: 8px
  - Border Radius: 4px
  - Font: Monospace, 12px
  - Color: Teal `#4ec9b0`
- **Max Height:** 200px, scrollable

### Interactions

1. **Refresh Interval:**
   - Dropdown to change update frequency
   - Applies immediately

2. **Real-time Updates:**
   - Metrics update at selected interval
   - Smooth transitions for bar animations

3. **Hover Effects:**
   - Cards slightly lift on hover
   - Tooltips on metrics for more info

---

## 🖥️ Tab 3: Full Antigravity Integration

### Layout Structure

```
┌─────────────────────────────────────────────────────────┐
│  ⚫ ⚫ ⚫  Project: Antigravity-Core [Dive Coder]         │
├─┬───────────────────────────────────────────────────┬───┤
│ │ 🤿 Dive Coder ✕                                   │ ≡ │
│ │ ┌─────┬─────────┬─────────┐                       │   │
│ │ │ CLI │ Metrics │ History │                       │   │
│ │ └─────┴─────────┴─────────┘                       │   │
│ │                                                    │   │
│ │ antigravity-user@sync-bridge:~$ dive-coder status │   │
│ │ Dive Coder is running. Sync Bridge is connected.  │   │
│ │                                                    │   │
│ │ antigravity-user@sync-bridge:~$ dive-coder build  │   │
│ │ Building module-a...                              │   │
│ │ [INFO] Compiling source files...                  │   │
│ │ [INFO] Linking dependencies...                    │   │
│ │ [SUCCESS] Build complete for module-a in 2.4s.    │   │
│ │                                                    │   │
│ │ antigravity-user@sync-bridge:~$ dive-coder deploy│   │
│ │ Deploying module-a to staging environment...      │   │
│ │ [INFO] Uploading artifacts...                     │   │
│ │ [INFO] Verifying deployment...                    │   │
│ │ [SUCCESS] Deployment to staging successful.       │   │
│ │                                                    │   │
│ │ antigravity-user@sync-bridge:~$ dive-coder logs   │   │
│ │ [2024-05-22T14:30:01Z] [INFO] Module initialized  │   │
│ │ [2024-05-22T14:30:05Z] [WARN] Connection latency  │   │
│ │ [2024-05-22T14:30:10Z] [ERROR] Failed to fetch    │   │
│ │ [2024-05-22T14:30:12Z] [INFO] Retrying request... │   │
│ │ [2024-05-22T14:30:15Z] [INFO] Request successful  │   │
│ │ [2024-05-22T14:30:20Z] [INFO] Processing data...  │   │
│ │ [2024-05-22T14:30:25Z] [INFO] Data complete.      │   │
│ │ [2024-05-22T14:30:30Z] [INFO] Module standing by. │   │
│ │                                                    │   │
│ │ antigravity-user@sync-bridge:~$ █                 │   │
├─┴───────────────────────────────────────────────────┴───┤
│ ✓ Connected to Sync Bridge    Ln 45, Col 12   UTF-8    │
└─────────────────────────────────────────────────────────┘

Left Sidebar:
┌───┐
│ 📁 │  Files
│ 🔍 │  Search
│ 🔀 │  Source Control
│ ▶️ │  Run & Debug
│ 🤿 │  Dive Coder ← NEW
│ 👤 │  Account
│ ⚙️ │  Settings
└───┘

Right Panel (Mini Metrics):
┌─────────────────────┐
│ Dive Coder Metrics  │
├─────────────────────┤
│ CPU Usage      15%  │
│ ▁▂▃▄▅▄▃▂▁          │
│                     │
│ Memory    1.2/4 GB  │
│ ████░░░░░░░░        │
│                     │
│ Network             │
│ ↓ 50 KB/s ↑ 20 KB/s │
│ ▁▂▁▃▂▁▄▃▂▁          │
│                     │
│ Latency      45 ms  │
│ 🟢 Synced           │
│                     │
│ Active Sessions: 3  │
└─────────────────────┘
```

### Design Elements

#### Window Chrome
- **macOS Style:** Traffic lights (⚫⚫⚫) top-left
- **Title Bar:** Dark `#2d2d30`
- **Project Name:** White, centered

#### Left Sidebar
- **Background:** `#252526`
- **Width:** 48px
- **Icons:** 
  - Default: Gray `#858585`
  - Active: Teal `#4ec9b0`
  - Hover: White `#e0e0e0`
- **Dive Coder Icon:** 🤿 (diving mask) or terminal icon

#### Main Tab Area
- **Tab Bar:**
  - Background: `#2d2d30`
  - Active Tab: `#1e1e1e` background, white text
  - Inactive Tab: Transparent, gray text
  - Close Button: ✕ on hover

#### Terminal Area
- **Full VS Code terminal aesthetic**
- **Prompt:** `antigravity-user@sync-bridge:~$`
- **Syntax highlighting** for commands
- **Log levels** color-coded

#### Right Panel (Mini Metrics)
- **Background:** `#252526`
- **Width:** 250px
- **Collapsible:** Yes
- **Real-time graphs:** Line charts with teal `#4ec9b0`
- **Compact metrics display**

#### Bottom Status Bar
- **Background:** `#007acc` (VS Code blue)
- **Height:** 22px
- **Items:**
  - Left: "✓ Connected to Sync Bridge" (green)
  - Center: Line/Col info
  - Right: Encoding, language

### Interactions

1. **Sidebar Icon:**
   - Click to toggle Dive Coder panel
   - Badge shows active sessions count

2. **Tab Switching:**
   - Click tabs to switch views
   - Keyboard shortcuts (Cmd+1, Cmd+2, Cmd+3)

3. **Panel Resizing:**
   - Drag borders to resize
   - Double-click to reset size

4. **Status Bar:**
   - Click "Connected" to show connection details
   - Hover for tooltips

---

## 🎨 Color Palette

### Primary Colors
- **Background Dark:** `#1e1e1e`
- **Background Medium:** `#252526`
- **Background Light:** `#2d2d30`
- **Border:** `#3e3e42`

### Text Colors
- **Primary:** `#e0e0e0`
- **Secondary:** `#858585`
- **Tertiary:** `#6a6a6a`

### Accent Colors
- **Teal (Primary):** `#4ec9b0`
- **Orange:** `#f4a261`
- **Red:** `#f48771` / `#e76f51`
- **Blue:** `#569cd6`
- **Green:** `#4ec9b0`
- **Yellow:** `#dcdcaa`

### Status Colors
- **Success:** `#4ec9b0` (teal)
- **Warning:** `#f4a261` (orange)
- **Error:** `#f48771` (red)
- **Info:** `#569cd6` (blue)

---

## 🔤 Typography

### Fonts
- **UI Text:** -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto
- **Monospace:** 'Fira Code', 'Courier New', monospace

### Sizes
- **Title:** 16px, Semi-bold
- **Header:** 14px, Semi-bold
- **Body:** 13px, Regular
- **Small:** 12px, Regular
- **Tiny:** 11px, Regular

### Line Heights
- **UI:** 1.5
- **Code:** 1.6
- **Compact:** 1.3

---

## 📐 Spacing

### Padding
- **Small:** 4px
- **Medium:** 8px
- **Large:** 12px
- **XLarge:** 16px

### Gaps
- **Tight:** 4px
- **Normal:** 8px
- **Relaxed:** 12px
- **Loose:** 16px

### Border Radius
- **Small:** 4px
- **Medium:** 6px
- **Large:** 8px

---

## ✨ Animations

### Transitions
- **Duration:** 0.2s - 0.3s
- **Easing:** ease, ease-in-out
- **Properties:** background, color, transform, opacity

### Hover Effects
- **Buttons:** Background change + slight lift
- **Cards:** Subtle shadow increase
- **Links:** Color change + underline

### Loading States
- **Spinner:** Rotating teal circle
- **Progress Bar:** Animated fill
- **Pulse:** Opacity animation for status dots

---

## 📱 Responsive Design

### Breakpoints
- **Desktop:** > 1024px (default)
- **Tablet:** 768px - 1024px
- **Mobile:** < 768px

### Adaptations
- **Tablet:** Stack metrics cards 2x2
- **Mobile:** Single column layout, collapsible panels

---

## ♿ Accessibility

### Keyboard Navigation
- **Tab:** Navigate between elements
- **Enter:** Execute/Select
- **Esc:** Close dropdowns/modals
- **↑↓:** Command history
- **Ctrl+C:** Copy output

### Screen Readers
- **ARIA labels** on all interactive elements
- **Alt text** for icons
- **Semantic HTML** structure

### Contrast
- **WCAG AA compliant** color contrast ratios
- **High contrast mode** support

---

## 🎯 Design Principles

1. **Consistency:** Follow VS Code / Antigravity design language
2. **Clarity:** Clear hierarchy and readable typography
3. **Efficiency:** Quick access to common actions
4. **Feedback:** Immediate visual feedback for all interactions
5. **Performance:** Smooth animations, no lag

---

## 📦 Assets Needed

### Icons
- Dive Coder logo (🤿 or custom)
- Tab icons (terminal, chart, history)
- Status indicators (checkmarks, dots)
- Action buttons (clear, copy, export)

### Fonts
- Fira Code (monospace)
- System fonts (UI)

### Images
- Loading spinner
- Empty state illustrations
- Error state illustrations

---

This design specification ensures a cohesive, professional, and user-friendly integration of Dive Coder into Antigravity!
