# /vibe-status

Mục tiêu: xem stack detect + versions các tool cài sẵn.

```bash
python3 .shared/vibe-coder-v13/vibe.py status --repo .
```

Tip: run /vibe-skills to browse external skill/tool options.
