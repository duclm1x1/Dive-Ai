# GEMINI.md patch (append)

Thêm dòng sau vào `.agent/rules/GEMINI.md` để bật Vibe Coder v13 rule-pack:

```md
@vibe-coder-v13.md
```
