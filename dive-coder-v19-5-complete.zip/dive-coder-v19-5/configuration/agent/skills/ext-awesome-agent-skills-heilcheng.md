# Awesome Agent Skills (heilcheng)

**Repo:** https://github.com/heilcheng/awesome-agent-skills

**Type:** curated-list

## Why this is useful
Another curated list with overlap + extra pointers.

## How to integrate with Antigravity + Vibe
Use as secondary index to reduce single-source bias.

## Recommended usage pattern
- Treat this as an **optional skill module**.
- If it introduces lint/test/security outputs, wire it into Vibe **Gates** and export **SARIF/Markdown**.
