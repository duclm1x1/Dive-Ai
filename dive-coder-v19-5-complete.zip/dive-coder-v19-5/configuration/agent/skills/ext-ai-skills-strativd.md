# AI Skills (strativd)

**Repo:** https://github.com/strativd/ai-skills

**Type:** skill-pack

## Why this is useful
Starter pack of skills in markdown; simple to copy into Antigravity.

## How to integrate with Antigravity + Vibe
Copy relevant SKILL.md items as separate skill files.

## Recommended usage pattern
- Treat this as an **optional skill module**.
- If it introduces lint/test/security outputs, wire it into Vibe **Gates** and export **SARIF/Markdown**.
